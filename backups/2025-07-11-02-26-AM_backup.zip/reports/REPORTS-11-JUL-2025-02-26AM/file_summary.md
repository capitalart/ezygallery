# 📊 File Summary

| File | Size (KB) | Last Modified |
|------|------------|----------------|
| `config.py` | 0.1 KB | 2025-07-10 23:52 |
| `git-update-push.sh` | 5.5 KB | 2025-07-11 02:20 |
| `ezygallery-total-rundown.py` | 8.8 KB | 2025-07-11 02:25 |
| `requirements.txt` | 1.1 KB | 2025-07-11 02:13 |
| `ezy.py` | 0.6 KB | 2025-07-10 23:52 |
| `setup_ezygallery_pro.sh` | 5.1 KB | 2025-07-10 23:47 |
| `templates/main.html` | 1.0 KB | 2025-07-10 23:52 |
| `templates/auth/login.html` | 0.2 KB | 2025-07-10 23:52 |
| `templates/gallery/gallery_home.html` | 0.2 KB | 2025-07-10 23:52 |
| `templates/marketplace/marketplace_home.html` | 0.2 KB | 2025-07-10 23:52 |
| `templates/components/header.html` | 0.1 KB | 2025-07-10 23:52 |
| `templates/admin/admin_home.html` | 0.2 KB | 2025-07-10 23:52 |
| `routes/gallery.py` | 0.2 KB | 2025-07-10 23:52 |
| `routes/auth.py` | 0.2 KB | 2025-07-10 23:52 |
| `routes/admin.py` | 0.2 KB | 2025-07-10 23:52 |
| `routes/marketplace.py` | 0.3 KB | 2025-07-10 23:52 |
| `static/css/theme.css` | 0.0 KB | 2025-07-10 23:52 |
| `static/css/components.css` | 0.0 KB | 2025-07-10 23:52 |
| `static/css/layout.css` | 0.0 KB | 2025-07-10 23:52 |
| `static/css/sidebar.css` | 0.0 KB | 2025-07-10 23:52 |
| `static/css/base.css` | 0.1 KB | 2025-07-10 23:52 |
| `static/js/base.js` | 0.0 KB | 2025-07-10 23:52 |
