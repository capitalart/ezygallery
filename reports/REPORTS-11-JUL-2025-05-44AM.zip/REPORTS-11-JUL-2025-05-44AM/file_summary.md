# 📊 File Summary

| File | Size (KB) | Last Modified |
|------|------------|----------------|
| `config.py` | 0.1 KB | 2025-07-11 05:29 |
| `git-update-push.sh` | 5.5 KB | 2025-07-11 05:29 |
| `ezygallery-total-rundown.py` | 8.8 KB | 2025-07-11 05:29 |
| `requirements.txt` | 1.1 KB | 2025-07-11 05:29 |
| `ezy.py` | 0.6 KB | 2025-07-11 05:29 |
| `setup_ezygallery_pro.sh` | 5.1 KB | 2025-07-11 05:29 |
| `templates/main.html` | 1.0 KB | 2025-07-11 05:29 |
| `templates/auth/login.html` | 0.2 KB | 2025-07-11 05:29 |
| `templates/gallery/gallery_home.html` | 0.2 KB | 2025-07-11 05:29 |
| `templates/marketplace/marketplace_home.html` | 0.2 KB | 2025-07-11 05:29 |
| `templates/components/header.html` | 0.1 KB | 2025-07-11 05:29 |
| `templates/admin/admin_home.html` | 0.2 KB | 2025-07-11 05:29 |
| `routes/gallery.py` | 0.2 KB | 2025-07-11 05:29 |
| `routes/auth.py` | 0.2 KB | 2025-07-11 05:29 |
| `routes/admin.py` | 0.2 KB | 2025-07-11 05:29 |
| `routes/marketplace.py` | 0.3 KB | 2025-07-11 05:29 |
| `static/css/theme.css` | 0.0 KB | 2025-07-11 05:29 |
| `static/css/components.css` | 0.0 KB | 2025-07-11 05:29 |
| `static/css/layout.css` | 0.0 KB | 2025-07-11 05:29 |
| `static/css/sidebar.css` | 0.0 KB | 2025-07-11 05:29 |
| `static/css/base.css` | 0.1 KB | 2025-07-11 05:29 |
| `static/js/base.js` | 0.0 KB | 2025-07-11 05:29 |
